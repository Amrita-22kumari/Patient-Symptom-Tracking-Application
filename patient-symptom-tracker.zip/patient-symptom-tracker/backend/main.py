
from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pathlib import Path
import database
import crud
import schemas
from database import get_db

database.Base.metadata.create_all(bind=database.engine)
app = FastAPI(title="Patient Symptom Tracker", version="1.0.0")
BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

@app.get("/")
def home():
    return FileResponse(FRONTEND_DIR / "index.html")

app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

@app.post("/symptoms", response_model=schemas.SymptomResponse)
def submit_symptom(symptom: schemas.SymptomCreate, db: Session = Depends(get_db)):
    try:
        result = crud.create_symptom(db, symptom)
        return result
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Unable to save symptom")

@app.get("/patients/{patient_id}/symptoms", response_model=list[schemas.SymptomResponse])
def get_symptoms(patient_id: str, db: Session = Depends(get_db)):
    if not patient_id.strip():
        raise HTTPException(status_code=400, detail="Patient ID cannot be empty")
    return crud.get_patient_symptoms(db, patient_id)

@app.get("/patients/{patient_id}/symptoms/trends")
def symptom_trends(patient_id: str, db: Session = Depends(get_db)):
    if not patient_id.strip():
        raise HTTPException(status_code=400, detail="Patient ID cannot be empty")
    return crud.get_symptom_trends(db, patient_id)

@app.get("/health")
def health_check():
    return {"status": "healthy"}
