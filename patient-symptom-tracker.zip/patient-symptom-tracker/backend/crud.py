
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta, timezone
from models import SymptomLog

def create_symptom(db: Session, symptom):
    latest = db.query(func.max(SymptomLog.timestamp)).scalar()
    current_time = datetime.now(timezone.utc).replace(tzinfo=None)
    if latest is not None and current_time <= latest:
        current_time = latest + timedelta(microseconds=1)
    new_symptom = SymptomLog(
        patient_id=symptom.patient_id,
        symptom_description=symptom.symptom_description,
        severity=symptom.severity,
        timestamp=current_time
    )
    db.add(new_symptom)
    db.commit()
    db.refresh(new_symptom)
    return new_symptom

def get_patient_symptoms(db: Session, patient_id):
    return db.query(SymptomLog).filter(SymptomLog.patient_id == patient_id).order_by(SymptomLog.timestamp.asc(), SymptomLog.id.asc()).all()

def get_symptom_trends(db: Session, patient_id):
    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=30)
    logs = db.query(SymptomLog).filter(SymptomLog.patient_id == patient_id, SymptomLog.timestamp >= cutoff).order_by(SymptomLog.timestamp.asc()).all()
    daily_data = {}
    for log in logs:
        day = log.timestamp.date().isoformat()
        daily_data.setdefault(day, []).append(log.severity)
    trends = []
    for day, values in sorted(daily_data.items()):
        trends.append({
            "date": day,
            "average_severity": round(sum(values) / len(values), 2)
        })
    return trends
