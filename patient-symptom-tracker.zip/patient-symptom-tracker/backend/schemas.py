
from pydantic import BaseModel, Field, field_validator
from datetime import datetime

class SymptomCreate(BaseModel):
    patient_id: str = Field(min_length=1, max_length=100)
    symptom_description: str = Field(min_length=1, max_length=500)
    severity: int = Field(ge=1, le=10)

    @field_validator("patient_id", "symptom_description")
    @classmethod
    def validate_not_empty(cls, value):
        if not value.strip():
            raise ValueError("Field cannot be empty")
        return value.strip()

class SymptomResponse(BaseModel):
    id: int
    patient_id: str
    symptom_description: str
    severity: int
    timestamp: datetime
    class Config:
        from_attributes = True
