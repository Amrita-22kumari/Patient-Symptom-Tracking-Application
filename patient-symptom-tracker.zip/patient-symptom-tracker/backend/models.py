
from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime, timezone
from database import Base

class SymptomLog(Base):
    __tablename__ = "symptom_logs"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(String(100), nullable=False, index=True)
    symptom_description = Column(String(500), nullable=False)
    severity = Column(Integer, nullable=False)
    timestamp = Column(DateTime, nullable=False, unique=True, index=True, default=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
