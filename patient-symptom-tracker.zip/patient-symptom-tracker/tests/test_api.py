
import sys
import pytest

from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

sys.path.insert(
    0,
    "/content/patient-symptom-tracker/backend"
)

from main import app
from database import Base, get_db


# Create an isolated in-memory test database
SQLALCHEMY_DATABASE_URL = "sqlite://"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)

TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


def override_get_db():
    Base.metadata.create_all(bind=engine)

    db = TestingSessionLocal()

    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_database():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


def test_create_symptom():

    response = client.post(
        "/symptoms",
        json={
            "patient_id": "P001",
            "symptom_description": "Headache",
            "severity": 5
        }
    )

    assert response.status_code == 200
    assert response.json()["patient_id"] == "P001"


def test_reject_empty_symptom():

    response = client.post(
        "/symptoms",
        json={
            "patient_id": "P001",
            "symptom_description": "   ",
            "severity": 5
        }
    )

    assert response.status_code == 422


@pytest.mark.parametrize("severity", [0, 11, -1, 15])
def test_reject_invalid_severity(severity):

    response = client.post(
        "/symptoms",
        json={
            "patient_id": "P001",
            "symptom_description": "Headache",
            "severity": severity
        }
    )

    assert response.status_code == 422


def test_store_five_symptoms():

    symptoms = [
        ("Headache", 5),
        ("Fever", 7),
        ("Cough", 4),
        ("Fatigue", 6),
        ("Body pain", 8)
    ]

    for description, severity in symptoms:

        response = client.post(
            "/symptoms",
            json={
                "patient_id": "P001",
                "symptom_description": description,
                "severity": severity
            }
        )

        assert response.status_code == 200

    response = client.get(
        "/patients/P001/symptoms"
    )

    assert response.status_code == 200

    records = response.json()

    assert len(records) >= 5

    timestamps = [
        record["timestamp"]
        for record in records
    ]

    assert len(timestamps) == len(set(timestamps))

    assert timestamps == sorted(timestamps)


def test_patient_records_are_separate():

    client.post(
        "/symptoms",
        json={
            "patient_id": "P001",
            "symptom_description": "Headache",
            "severity": 5
        }
    )

    client.post(
        "/symptoms",
        json={
            "patient_id": "P002",
            "symptom_description": "Fever",
            "severity": 7
        }
    )

    response = client.get(
        "/patients/P001/symptoms"
    )

    records = response.json()

    assert all(
        record["patient_id"] == "P001"
        for record in records
    )
